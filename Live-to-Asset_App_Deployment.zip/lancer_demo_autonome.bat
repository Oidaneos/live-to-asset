@echo off
title OIDANEOS Live-to-Asset - Serveur et Tunnel Cloudflare
color 0B

echo ======================================================================
echo           OIDANEOS - PLATEFORME E-LEARNING (LIVE-TO-ASSET)
echo ======================================================================
echo.
echo [1/2] Demarrage du serveur local sur le port 3000...
start /B node server.js

timeout /t 2 /nobreak >nul

echo [2/2] Demarrage du tunnel public Cloudflare...
echo.
echo Laissez cette fenetre ouverte pour que le lien public reste accessible.
echo.
echo ======================================================================
echo URL locale   : http://localhost:3000
echo ======================================================================
echo.

cloudflared.exe tunnel --url http://localhost:3000
pause
